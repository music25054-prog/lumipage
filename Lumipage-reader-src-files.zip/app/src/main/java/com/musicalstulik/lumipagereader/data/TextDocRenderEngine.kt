package com.musicalstulik.lumipagereader.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import android.provider.OpenableColumns
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.LruCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.Closeable
import java.io.File
import java.io.InputStreamReader

class TextDocRenderEngine(
    private val context: Context,
    val uri: Uri,
    val isDocx: Boolean
) : Closeable {

    val fileName: String = resolveFileName(context, uri)
    private val pages = mutableListOf<List<String>>()

    val pageCount: Int

    private val bitmapCache = object : LruCache<String, Bitmap>(20) {
        override fun sizeOf(key: String, value: Bitmap): Int {
            return 1
        }
    }

    init {
        val rawParagraphs = if (isDocx) {
            DocxTextParser.parseDocx(context, uri)
        } else {
            readTextFile(context, uri)
        }

        paginate(rawParagraphs)
        pageCount = pages.size.coerceAtLeast(1)
    }

    private fun readTextFile(context: Context, uri: Uri): List<String> {
        return try {
            context.contentResolver.openInputStream(uri)?.use { inputStream ->
                InputStreamReader(inputStream, Charsets.UTF_8).useLines { lines ->
                    lines.toList()
                }
            } ?: listOf("Failed to open text file.")
        } catch (e: Exception) {
            listOf("Error reading text file: ${e.localizedMessage}")
        }
    }

    private fun paginate(paragraphs: List<String>) {
        val virtualWidth = 800
        val virtualHeight = 1131 // A4 ratio 1.414
        val marginHorizontal = 50
        val marginVertical = 60
        val contentWidth = virtualWidth - (marginHorizontal * 2)
        val contentHeight = virtualHeight - (marginVertical * 2)

        val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 24f
            color = Color.BLACK
        }

        var currentPageLines = mutableListOf<String>()
        var currentHeightUsed = 0

        for (paragraph in paragraphs) {
            val text = if (paragraph.isEmpty()) " " else paragraph
            @Suppress("DEPRECATION")
            val layout = StaticLayout(
                text,
                textPaint,
                contentWidth,
                Layout.Alignment.ALIGN_NORMAL,
                1.2f,
                0f,
                false
            )

            val paragraphHeight = layout.height + 12

            if (currentHeightUsed + paragraphHeight <= contentHeight || currentPageLines.isEmpty()) {
                currentPageLines.add(text)
                currentHeightUsed += paragraphHeight
            } else {
                pages.add(currentPageLines)
                currentPageLines = mutableListOf(text)
                currentHeightUsed = paragraphHeight
            }
        }

        if (currentPageLines.isNotEmpty()) {
            pages.add(currentPageLines)
        }

        if (pages.isEmpty()) {
            pages.add(listOf("Empty document."))
        }
    }

    suspend fun renderPage(
        pageIndex: Int,
        targetWidthPx: Int,
        scale: Float = 1.0f
    ): Bitmap? = withContext(Dispatchers.IO) {
        if (pageIndex !in 0 until pageCount) return@withContext null

        val scaledWidth = (targetWidthPx * scale).toInt().coerceAtLeast(100)
        val cacheKey = "$pageIndex-$scaledWidth"

        bitmapCache.get(cacheKey)?.let { cachedBitmap ->
            if (!cachedBitmap.isRecycled) {
                return@withContext cachedBitmap
            }
        }

        val virtualWidth = 800f
        val virtualHeight = 1131f // A4 ratio
        val renderScale = scaledWidth / virtualWidth
        val scaledHeight = (virtualHeight * renderScale).toInt().coerceAtLeast(100)

        val bitmap = Bitmap.createBitmap(scaledWidth, scaledHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Draw paper background
        canvas.drawColor(Color.WHITE)

        val marginHorizontal = 50f * renderScale
        val marginVertical = 60f * renderScale
        val contentWidth = (scaledWidth - (marginHorizontal * 2)).toInt().coerceAtLeast(10)

        val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 24f * renderScale
            color = Color.parseColor("#1C1B1F")
        }

        val lines = pages.getOrElse(pageIndex) { emptyList() }

        canvas.save()
        canvas.translate(marginHorizontal, marginVertical)

        for (paragraphText in lines) {
            @Suppress("DEPRECATION")
            val layout = StaticLayout(
                paragraphText,
                textPaint,
                contentWidth,
                Layout.Alignment.ALIGN_NORMAL,
                1.2f,
                0f,
                false
            )
            layout.draw(canvas)
            val spacing = 12f * renderScale
            canvas.translate(0f, layout.height + spacing)
        }
        canvas.restore()

        bitmapCache.put(cacheKey, bitmap)
        return@withContext bitmap
    }

    fun getPageAspectRatio(pageIndex: Int): Float {
        return 1.414f // Standard A4 ratio
    }

    override fun close() {
        bitmapCache.evictAll()
        pages.clear()
    }

    companion object {
        private fun resolveFileName(context: Context, uri: Uri): String {
            if (uri.scheme == "content") {
                try {
                    context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                        val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (nameIndex != -1 && cursor.moveToFirst()) {
                            val name = cursor.getString(nameIndex)
                            if (!name.isNullOrBlank()) return name
                        }
                    }
                } catch (e: Exception) {
                    // Fallback
                }
            } else if (uri.scheme == "file") {
                val path = uri.path
                if (path != null) {
                    val file = File(path)
                    if (file.name.isNotBlank()) return file.name
                }
            }
            return uri.lastPathSegment ?: "Document.txt"
        }
    }
}
