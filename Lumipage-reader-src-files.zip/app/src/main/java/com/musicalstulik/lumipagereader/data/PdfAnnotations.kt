package com.musicalstulik.lumipagereader.data

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import java.util.UUID

data class MarginNote(
    val id: String = UUID.randomUUID().toString(),
    val pageIndex: Int,
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class SearchResult(
    val pageIndex: Int,
    val snippet: String,
    val matchType: String
)

enum class DrawingTool {
    PEN,
    HIGHLIGHTER,
    ERASER
}

data class DrawPath(
    val points: List<Offset>,
    val color: Color,
    val strokeWidth: Float,
    val isHighlighter: Boolean = false
)
