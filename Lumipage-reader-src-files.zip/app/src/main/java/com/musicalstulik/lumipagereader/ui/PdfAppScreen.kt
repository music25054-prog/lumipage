package com.musicalstulik.lumipagereader.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.musicalstulik.lumipagereader.R
import com.musicalstulik.lumipagereader.ui.components.ContinuousPdfViewer
import com.musicalstulik.lumipagereader.ui.components.EmptyPdfState
import com.musicalstulik.lumipagereader.ui.components.GoToPageDialog
import com.musicalstulik.lumipagereader.ui.components.SinglePdfViewer

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfAppScreen(
    viewModel: PdfViewModel,
    initialUri: Uri? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()
    val currentPage by viewModel.currentPage.collectAsState()
    val viewMode by viewModel.viewMode.collectAsState()
    val zoomScale by viewModel.zoomScale.collectAsState()
    val recentFiles by viewModel.recentFiles.collectAsState()
    val showGoToPageDialog by viewModel.showGoToPageDialog.collectAsState()

    val isSearchActive by viewModel.isSearchActive.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val searchResults by viewModel.searchResults.collectAsState()
    val marginNotes by viewModel.marginNotes.collectAsState()
    val showAddNoteDialog by viewModel.showAddNoteDialog.collectAsState()

    var showMenu by remember { mutableStateOf(false) }

    // File picker launcher
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let { viewModel.openPdf(context, it) }
    }

    LaunchedEffect(Unit) {
        viewModel.initRecentManager(context)
        if (initialUri != null) {
            viewModel.openPdf(context, initialUri)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    if (isSearchActive) {
                        TextField(
                            value = searchQuery,
                            onValueChange = { viewModel.searchDocument(it) },
                            placeholder = { Text("Search keywords or notes...") },
                            singleLine = true,
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent,
                                disabledContainerColor = Color.Transparent
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        Column(
                            modifier = if (uiState is PdfUiState.Success) {
                                Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .clickable { viewModel.setShowGoToPageDialog(true) }
                                    .padding(vertical = 2.dp, horizontal = 4.dp)
                            } else {
                                Modifier
                            }
                        ) {
                            Text(
                                text = when (val state = uiState) {
                                    is PdfUiState.Success -> state.fileName
                                    else -> stringResource(R.string.app_name)
                                },
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold
                            )
                            if (uiState is PdfUiState.Success) {
                                val success = uiState as PdfUiState.Success
                                Text(
                                    text = stringResource(R.string.page_indicator, currentPage + 1, success.pageCount),
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                },
                navigationIcon = {
                    if (isSearchActive) {
                        IconButton(onClick = { viewModel.setSearchActive(false) }) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Close Search"
                            )
                        }
                    } else if (uiState is PdfUiState.Success || uiState is PdfUiState.Error) {
                        IconButton(onClick = { viewModel.closeDocument() }) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Close PDF"
                            )
                        }
                    }
                },
                actions = {
                    if (uiState is PdfUiState.Success && !isSearchActive) {
                        val success = uiState as PdfUiState.Success

                        // Search Button
                        IconButton(onClick = { viewModel.setSearchActive(true) }) {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "Search"
                            )
                        }

                        // Add Margin Note Button
                        IconButton(onClick = { viewModel.setShowAddNoteDialog(true) }) {
                            Icon(
                                imageVector = Icons.Default.EditNote,
                                contentDescription = "Add Margin Note"
                            )
                        }

                        // Toggle View Mode (Continuous vs Single Page)
                        IconButton(onClick = { viewModel.toggleViewMode() }) {
                            Text(
                                text = if (viewMode == ViewMode.CONTINUOUS_SCROLL) stringResource(R.string.mode_single) else stringResource(R.string.mode_continuous),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        // Overflow Options Menu
                        Box {
                            IconButton(onClick = { showMenu = true }) {
                                Icon(
                                    imageVector = Icons.Default.MoreVert,
                                    contentDescription = "More Options"
                                )
                            }
                            DropdownMenu(
                                expanded = showMenu,
                                onDismissRequest = { showMenu = false }
                            ) {
                                // Share PDF
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.share_pdf)) },
                                    onClick = {
                                        showMenu = false
                                        sharePdf(context, success.uri)
                                    },
                                    leadingIcon = {
                                        Icon(
                                            imageVector = Icons.Default.Share,
                                            contentDescription = null
                                        )
                                    }
                                )

                                // Open another PDF
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.open_pdf)) },
                                    onClick = {
                                        showMenu = false
                                        filePickerLauncher.launch(arrayOf("application/pdf"))
                                    },
                                    leadingIcon = {
                                        Icon(
                                            imageVector = Icons.Default.Add,
                                            contentDescription = null
                                        )
                                    }
                                )

                                // Switch Language
                                val currentLocales = AppCompatDelegate.getApplicationLocales()
                                val currentLang = if (!currentLocales.isEmpty) currentLocales[0]?.language else java.util.Locale.getDefault().language
                                val isRussian = currentLang == "ru"
                                DropdownMenuItem(
                                    text = { Text(if (isRussian) "Язык: RU" else "Language: EN") },
                                    onClick = {
                                        showMenu = false
                                        val newLang = if (isRussian) "en" else "ru"
                                        AppCompatDelegate.setApplicationLocales(
                                            LocaleListCompat.forLanguageTags(newLang)
                                        )
                                    }
                                )
                            }
                        }
                    } else if (isSearchActive) {
                        IconButton(onClick = { viewModel.clearSearch() }) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Clear Search"
                            )
                        }
                    } else {
                        // When no PDF is open
                        val currentLocales = AppCompatDelegate.getApplicationLocales()
                        val currentLang = if (!currentLocales.isEmpty) currentLocales[0]?.language else java.util.Locale.getDefault().language
                        val isRussian = currentLang == "ru"
                        Surface(
                            onClick = {
                                val newLang = if (isRussian) "en" else "ru"
                                AppCompatDelegate.setApplicationLocales(
                                    LocaleListCompat.forLanguageTags(newLang)
                                )
                            },
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.secondaryContainer,
                            modifier = Modifier.padding(end = 4.dp)
                        ) {
                            Text(
                                text = if (isRussian) "RU" else "EN",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }

                        IconButton(onClick = { filePickerLauncher.launch(arrayOf("application/pdf")) }) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = stringResource(R.string.open_pdf)
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            if (uiState is PdfUiState.Success && !isSearchActive) {
                Surface(
                    shadowElevation = 8.dp,
                    color = MaterialTheme.colorScheme.surfaceContainer
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .navigationBarsPadding()
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // View Mode Indicator
                        Text(
                            text = if (viewMode == ViewMode.CONTINUOUS_SCROLL) "Scroll Mode" else "Page Mode",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        // Zoom Controls
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            TextButton(onClick = { viewModel.zoomOut() }) {
                                Text("-", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            }

                            TextButton(onClick = { viewModel.resetZoom() }) {
                                Text("${(zoomScale * 100).toInt()}%", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            }

                            TextButton(onClick = { viewModel.zoomIn() }) {
                                Text("+", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        },
        modifier = modifier
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (val state = uiState) {
                is PdfUiState.Empty -> {
                    EmptyPdfState(
                        recentFiles = recentFiles,
                        onOpenFilePicker = { filePickerLauncher.launch(arrayOf("application/pdf")) },
                        onSelectRecentFile = { uri -> viewModel.openPdf(context, uri) },
                        onRemoveRecentFile = { uriStr -> viewModel.removeRecentFile(uriStr) },
                        onClearAllRecent = { viewModel.clearRecentFiles() }
                    )
                }

                is PdfUiState.Loading -> {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(text = "Loading PDF document...", fontSize = 16.sp)
                    }
                }

                is PdfUiState.Error -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "Cannot Open Document",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = state.message,
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                Button(onClick = { filePickerLauncher.launch(arrayOf("application/pdf")) }) {
                                    Text("Open Another File")
                                }
                            }
                        }
                    }
                }

                is PdfUiState.Success -> {
                    if (viewMode == ViewMode.CONTINUOUS_SCROLL) {
                        ContinuousPdfViewer(
                            pageCount = state.pageCount,
                            currentPage = currentPage,
                            zoomScale = zoomScale,
                            renderPage = { index, widthPx, scale -> viewModel.renderPage(index, widthPx, scale) },
                            getPageAspectRatio = { index -> viewModel.getPageAspectRatio(index) },
                            onPageChanged = { page -> viewModel.setCurrentPage(page) },
                            marginNotes = marginNotes,
                            onDeleteNote = { noteId -> viewModel.removeMarginNote(noteId) }
                        )
                    } else {
                        SinglePdfViewer(
                            pageCount = state.pageCount,
                            currentPage = currentPage,
                            zoomScale = zoomScale,
                            renderPage = { index, widthPx, scale -> viewModel.renderPage(index, widthPx, scale) },
                            getPageAspectRatio = { index -> viewModel.getPageAspectRatio(index) },
                            onNextPage = { viewModel.setCurrentPage(currentPage + 1) },
                            onPreviousPage = { viewModel.setCurrentPage(currentPage - 1) },
                            marginNotes = marginNotes,
                            onDeleteNote = { noteId -> viewModel.removeMarginNote(noteId) }
                        )
                    }

                    if (showGoToPageDialog) {
                        GoToPageDialog(
                            currentPage = currentPage,
                            pageCount = state.pageCount,
                            onDismiss = { viewModel.setShowGoToPageDialog(false) },
                            onGoToPage = { targetPage -> viewModel.setCurrentPage(targetPage) }
                        )
                    }

                    if (showAddNoteDialog) {
                        AddMarginNoteDialog(
                            currentPage = currentPage,
                            onDismiss = { viewModel.setShowAddNoteDialog(false) },
                            onAddNote = { text -> viewModel.addMarginNote(currentPage, text) }
                        )
                    }

                    // Search Results Overlay when searching
                    if (isSearchActive && searchQuery.isNotBlank()) {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                                .align(Alignment.TopCenter),
                            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "Search Results (${searchResults.size})",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                if (searchResults.isEmpty()) {
                                    Text(
                                        text = "No matches found for \"$searchQuery\"",
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(vertical = 8.dp)
                                    )
                                } else {
                                    LazyColumn(
                                        modifier = Modifier.height(200.dp),
                                        verticalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        items(searchResults) { result ->
                                            Surface(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clickable {
                                                        viewModel.setCurrentPage(result.pageIndex)
                                                        viewModel.setSearchActive(false)
                                                    },
                                                shape = RoundedCornerShape(8.dp),
                                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                            ) {
                                                Column(modifier = Modifier.padding(8.dp)) {
                                                    Text(
                                                        text = "Page ${result.pageIndex + 1} • ${result.matchType}",
                                                        fontSize = 12.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = MaterialTheme.colorScheme.primary
                                                    )
                                                    Text(
                                                        text = result.snippet,
                                                        fontSize = 13.sp,
                                                        color = MaterialTheme.colorScheme.onSurface
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AddMarginNoteDialog(
    currentPage: Int,
    onDismiss: () -> Unit,
    onAddNote: (String) -> Unit
) {
    var text by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Margin Note (Page ${currentPage + 1})") },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                label = { Text("Note text") },
                singleLine = false,
                maxLines = 3,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            TextButton(
                onClick = {
                    if (text.isNotBlank()) {
                        onAddNote(text)
                        onDismiss()
                    }
                }
            ) {
                Text("Add")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

private fun sharePdf(context: Context, uri: Uri) {
    try {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Share PDF Document"))
    } catch (e: Exception) {
        e.printStackTrace()
    }
}
