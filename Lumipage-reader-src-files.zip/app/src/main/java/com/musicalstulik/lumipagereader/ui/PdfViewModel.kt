package com.musicalstulik.lumipagereader.ui

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.musicalstulik.lumipagereader.data.DocumentRenderEngine
import com.musicalstulik.lumipagereader.data.DrawPath
import com.musicalstulik.lumipagereader.data.DrawingTool
import com.musicalstulik.lumipagereader.data.MarginNote
import com.musicalstulik.lumipagereader.data.RecentFilesManager
import com.musicalstulik.lumipagereader.data.RecentPdfItem
import com.musicalstulik.lumipagereader.data.SearchResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class ViewMode {
    CONTINUOUS_SCROLL,
    SINGLE_PAGE
}

sealed interface PdfUiState {
    object Empty : PdfUiState
    object Loading : PdfUiState
    data class Success(
        val fileName: String,
        val pageCount: Int,
        val uri: Uri
    ) : PdfUiState
    data class Error(val message: String) : PdfUiState
}

class PdfViewModel : ViewModel() {

    private val _uiState = MutableStateFlow<PdfUiState>(PdfUiState.Empty)
    val uiState: StateFlow<PdfUiState> = _uiState.asStateFlow()

    private val _currentPage = MutableStateFlow(0)
    val currentPage: StateFlow<Int> = _currentPage.asStateFlow()

    private val _viewMode = MutableStateFlow(ViewMode.CONTINUOUS_SCROLL)
    val viewMode: StateFlow<ViewMode> = _viewMode.asStateFlow()

    private val _zoomScale = MutableStateFlow(1.0f)
    val zoomScale: StateFlow<Float> = _zoomScale.asStateFlow()

    private val _recentFiles = MutableStateFlow<List<RecentPdfItem>>(emptyList())
    val recentFiles: StateFlow<List<RecentPdfItem>> = _recentFiles.asStateFlow()

    private val _showGoToPageDialog = MutableStateFlow(false)
    val showGoToPageDialog: StateFlow<Boolean> = _showGoToPageDialog.asStateFlow()

    // Annotations (Margin Notes) & Search state
    private val _marginNotes = MutableStateFlow<List<MarginNote>>(emptyList())
    val marginNotes: StateFlow<List<MarginNote>> = _marginNotes.asStateFlow()

    private val _isSearchActive = MutableStateFlow(false)
    val isSearchActive: StateFlow<Boolean> = _isSearchActive.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _searchResults = MutableStateFlow<List<SearchResult>>(emptyList())
    val searchResults: StateFlow<List<SearchResult>> = _searchResults.asStateFlow()

    private val _showAddNoteDialog = MutableStateFlow(false)
    val showAddNoteDialog: StateFlow<Boolean> = _showAddNoteDialog.asStateFlow()

    // Drawing Overlay state
    private val _isDrawingMode = MutableStateFlow(false)
    val isDrawingMode: StateFlow<Boolean> = _isDrawingMode.asStateFlow()

    private val _currentTool = MutableStateFlow(DrawingTool.HIGHLIGHTER)
    val currentTool: StateFlow<DrawingTool> = _currentTool.asStateFlow()

    private val _selectedColor = MutableStateFlow(Color(0xFFFFEB3B)) // Yellow
    val selectedColor: StateFlow<Color> = _selectedColor.asStateFlow()

    private val _selectedStrokeWidth = MutableStateFlow(32f)
    val selectedStrokeWidth: StateFlow<Float> = _selectedStrokeWidth.asStateFlow()

    private val _pageDrawings = MutableStateFlow<Map<Int, List<DrawPath>>>(emptyMap())
    val pageDrawings: StateFlow<Map<Int, List<DrawPath>>> = _pageDrawings.asStateFlow()

    private var pdfEngine: DocumentRenderEngine? = null
    private var recentFilesManager: RecentFilesManager? = null

    fun initRecentManager(context: Context) {
        if (recentFilesManager == null) {
            recentFilesManager = RecentFilesManager(context.applicationContext)
            loadRecentFiles()
        }
    }

    fun loadRecentFiles() {
        _recentFiles.value = recentFilesManager?.getRecentFiles() ?: emptyList()
    }

    fun openPdf(context: Context, uri: Uri) {
        viewModelScope.launch {
            _uiState.value = PdfUiState.Loading

            // Take persistable permission if available
            try {
                val takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION
                context.contentResolver.takePersistableUriPermission(uri, takeFlags)
            } catch (e: Exception) {
                // Ignore if not supported or not allowed
            }

            // Close existing engine
            pdfEngine?.close()
            pdfEngine = null
            _marginNotes.value = emptyList()
            clearSearch()

            try {
                val engine = DocumentRenderEngine.create(context.applicationContext, uri)
                pdfEngine = engine

                initRecentManager(context)
                
                val savedLastPage = recentFilesManager?.getRecentFiles()
                    ?.firstOrNull { it.uriString == uri.toString() }?.lastPage ?: 0

                val initialPage = if (savedLastPage in 0 until engine.pageCount) savedLastPage else 0
                _currentPage.value = initialPage
                _zoomScale.value = 1.0f

                recentFilesManager?.addOrUpdateRecentFile(
                    uri = uri,
                    fileName = engine.fileName,
                    totalPages = engine.pageCount,
                    lastPage = initialPage
                )
                loadRecentFiles()

                _uiState.value = PdfUiState.Success(
                    fileName = engine.fileName,
                    pageCount = engine.pageCount,
                    uri = uri
                )
            } catch (e: IllegalArgumentException) {
                _uiState.value = PdfUiState.Error(e.message ?: "Failed to open PDF document.")
            } catch (e: Exception) {
                _uiState.value = PdfUiState.Error("An error occurred while opening the PDF: ${e.localizedMessage}")
            }
        }
    }

    suspend fun renderPage(pageIndex: Int, targetWidthPx: Int, scale: Float = 1.0f): Bitmap? {
        return pdfEngine?.renderPage(pageIndex, targetWidthPx, scale)
    }

    fun getPageAspectRatio(pageIndex: Int): Float {
        return pdfEngine?.getPageAspectRatio(pageIndex) ?: 1.414f
    }

    fun setCurrentPage(page: Int) {
        val state = _uiState.value
        if (state is PdfUiState.Success) {
            val clampedPage = page.coerceIn(0, state.pageCount - 1)
            _currentPage.value = clampedPage
            pdfEngine?.let { engine ->
                recentFilesManager?.updateLastPage(engine.uri, clampedPage)
            }
        }
    }

    fun setViewMode(mode: ViewMode) {
        _viewMode.value = mode
    }

    fun toggleViewMode() {
        _viewMode.update {
            if (it == ViewMode.CONTINUOUS_SCROLL) ViewMode.SINGLE_PAGE else ViewMode.CONTINUOUS_SCROLL
        }
    }

    fun setZoomScale(scale: Float) {
        _zoomScale.value = scale.coerceIn(0.5f, 3.5f)
    }

    fun zoomIn() {
        setZoomScale(_zoomScale.value + 0.25f)
    }

    fun zoomOut() {
        setZoomScale(_zoomScale.value - 0.25f)
    }

    fun resetZoom() {
        _zoomScale.value = 1.0f
    }

    fun setShowGoToPageDialog(show: Boolean) {
        _showGoToPageDialog.value = show
    }

    // Margin Notes management
    fun addMarginNote(pageIndex: Int, text: String) {
        if (text.isBlank()) return
        val newNote = MarginNote(pageIndex = pageIndex, text = text.trim())
        _marginNotes.update { it + newNote }
    }

    fun removeMarginNote(noteId: String) {
        _marginNotes.update { notes -> notes.filter { it.id != noteId } }
    }

    fun setShowAddNoteDialog(show: Boolean) {
        _showAddNoteDialog.value = show
    }

    // Search functionality
    fun setSearchActive(active: Boolean) {
        _isSearchActive.value = active
        if (!active) {
            clearSearch()
        }
    }

    fun searchDocument(query: String) {
        _searchQuery.value = query
        val trimmed = query.trim()
        if (trimmed.isEmpty()) {
            _searchResults.value = emptyList()
            return
        }

        val results = mutableListOf<SearchResult>()
        val notes = _marginNotes.value
        for (note in notes) {
            if (note.text.contains(trimmed, ignoreCase = true)) {
                results.add(
                    SearchResult(
                        pageIndex = note.pageIndex,
                        snippet = "Note: ${note.text}",
                        matchType = "Margin Note"
                    )
                )
            }
        }

        val state = _uiState.value
        if (state is PdfUiState.Success) {
            for (i in 0 until state.pageCount) {
                val pageNumStr = (i + 1).toString()
                if (pageNumStr.contains(trimmed, ignoreCase = true)) {
                    results.add(
                        SearchResult(
                            pageIndex = i,
                            matchType = "Page",
                            snippet = "Page ${i + 1}"
                        )
                    )
                }
            }
        }

        _searchResults.value = results.distinctBy { it.pageIndex to it.snippet }
    }

    fun clearSearch() {
        _searchQuery.value = ""
        _searchResults.value = emptyList()
    }

    // Drawing Overlay Management
    fun toggleDrawingMode() {
        _isDrawingMode.update { !it }
    }

    fun setDrawingMode(enabled: Boolean) {
        _isDrawingMode.value = enabled
    }

    fun setDrawingTool(tool: DrawingTool) {
        _currentTool.value = tool
        if (tool == DrawingTool.HIGHLIGHTER) {
            _selectedStrokeWidth.value = 32f
            if (_selectedColor.value == Color.Black) {
                _selectedColor.value = Color(0xFFFFEB3B) // Yellow default
            }
        } else if (tool == DrawingTool.PEN) {
            _selectedStrokeWidth.value = 8f
            if (_selectedColor.value == Color(0xFFFFEB3B)) {
                _selectedColor.value = Color(0xFF2196F3) // Blue
            }
        }
    }

    fun setSelectedColor(color: Color) {
        _selectedColor.value = color
    }

    fun setSelectedStrokeWidth(width: Float) {
        _selectedStrokeWidth.value = width
    }

    fun addDrawPath(pageIndex: Int, path: DrawPath) {
        _pageDrawings.update { currentMap ->
            val existing = currentMap[pageIndex] ?: emptyList()
            currentMap + (pageIndex to (existing + path))
        }
    }

    fun undoDrawPath(pageIndex: Int) {
        _pageDrawings.update { currentMap ->
            val existing = currentMap[pageIndex] ?: emptyList()
            if (existing.isNotEmpty()) {
                currentMap + (pageIndex to existing.dropLast(1))
            } else currentMap
        }
    }

    fun clearDrawings(pageIndex: Int) {
        _pageDrawings.update { currentMap ->
            currentMap - pageIndex
        }
    }

    fun closeDocument() {
        pdfEngine?.close()
        pdfEngine = null
        _uiState.value = PdfUiState.Empty
        _currentPage.value = 0
        _zoomScale.value = 1.0f
        _marginNotes.value = emptyList()
        _pageDrawings.value = emptyMap()
        _isDrawingMode.value = false
        clearSearch()
    }

    fun removeRecentFile(uriString: String) {
        recentFilesManager?.removeRecentFile(uriString)
        loadRecentFiles()
    }

    fun clearRecentFiles() {
        recentFilesManager?.clearAll()
        loadRecentFiles()
    }

    override fun onCleared() {
        super.onCleared()
        pdfEngine?.close()
        pdfEngine = null
    }
}
