package com.musicalstulik.lumipagereader.data

import android.content.Context
import android.net.Uri
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.InputStream
import java.util.zip.ZipInputStream

object DocxTextParser {

    fun parseDocx(context: Context, uri: Uri): List<String> {
        val paragraphs = mutableListOf<String>()
        val inputStream: InputStream = context.contentResolver.openInputStream(uri)
            ?: return listOf("Failed to open DOCX file.")

        try {
            ZipInputStream(inputStream).use { zipStream ->
                var entry = zipStream.nextEntry
                while (entry != null) {
                    if (entry.name == "word/document.xml") {
                        parseDocumentXml(zipStream, paragraphs)
                        break
                    }
                    zipStream.closeEntry()
                    entry = zipStream.nextEntry
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return if (paragraphs.isEmpty()) listOf("Empty or unreadable DOCX document.") else paragraphs
    }

    private fun parseDocumentXml(inputStream: InputStream, paragraphs: MutableList<String>) {
        try {
            val parser = Xml.newPullParser()
            parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
            parser.setInput(inputStream, "UTF-8")

            var eventType = parser.eventType
            val currentParagraph = StringBuilder()
            var inParagraph = false

            while (eventType != XmlPullParser.END_DOCUMENT) {
                when (eventType) {
                    XmlPullParser.START_TAG -> {
                        val tagName = parser.name
                        if (tagName == "p" || tagName.endsWith(":p")) {
                            inParagraph = true
                            currentParagraph.setLength(0)
                        } else if (inParagraph && (tagName == "t" || tagName.endsWith(":t"))) {
                            val text = parser.nextText()
                            currentParagraph.append(text)
                        }
                    }
                    XmlPullParser.END_TAG -> {
                        val tagName = parser.name
                        if (tagName == "p" || tagName.endsWith(":p")) {
                            inParagraph = false
                            val text = currentParagraph.toString().trim()
                            paragraphs.add(text)
                        }
                    }
                }
                eventType = parser.next()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
