package com.musicalstulik.lumipagereader.data

import java.util.UUID

data class MarginNote(
    val id: String = UUID.randomUUID().toString(),
    val pageIndex: Int,
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class SearchResult(
    val pageIndex: Int,
    val snippet: String,
    val matchType: String
)
