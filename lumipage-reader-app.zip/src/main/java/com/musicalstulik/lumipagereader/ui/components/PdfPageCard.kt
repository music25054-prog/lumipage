package com.musicalstulik.lumipagereader.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.musicalstulik.lumipagereader.R
import com.musicalstulik.lumipagereader.data.MarginNote

@Composable
fun PdfPageCard(
    pageIndex: Int,
    targetWidthPx: Int,
    aspectRatio: Float,
    renderPage: suspend (pageIndex: Int, targetWidthPx: Int, scale: Float) -> Bitmap?,
    scale: Float = 1.0f,
    pageNotes: List<MarginNote> = emptyList(),
    onDeleteNote: (String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    var bitmap by remember(pageIndex, targetWidthPx, scale) { mutableStateOf<Bitmap?>(null) }
    var isLoading by remember(pageIndex, targetWidthPx, scale) { mutableStateOf(true) }

    LaunchedEffect(pageIndex, targetWidthPx, scale) {
        if (targetWidthPx > 0) {
            isLoading = true
            bitmap = renderPage(pageIndex, targetWidthPx, scale)
            isLoading = false
        }
    }

    val resolvedModifier = if (modifier == Modifier) {
        Modifier.fillMaxWidth().aspectRatio(1f / aspectRatio)
    } else {
        modifier
    }

    Card(
        modifier = resolvedModifier.padding(vertical = 4.dp, horizontal = 8.dp),
        shape = RoundedCornerShape(8.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.White),
            contentAlignment = Alignment.Center
        ) {
            val currentBitmap = bitmap
            if (currentBitmap != null && !currentBitmap.isRecycled) {
                Image(
                    bitmap = currentBitmap.asImageBitmap(),
                    contentDescription = stringResource(R.string.page_indicator, pageIndex + 1, 0),
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )
            } else if (isLoading) {
                CircularProgressIndicator(
                    modifier = Modifier.size(36.dp),
                    color = MaterialTheme.colorScheme.primary,
                    strokeWidth = 3.dp
                )
            } else {
                Text(
                    text = stringResource(R.string.failed_to_render_page, pageIndex + 1),
                    color = MaterialTheme.colorScheme.error,
                    fontSize = 14.sp
                )
            }

            // Margin Notes Overlay (Sticky notes on page margin)
            if (pageNotes.isNotEmpty()) {
                Column(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp),
                    verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(4.dp)
                ) {
                    for (note in pageNotes) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFFFFEB3B).copy(alpha = 0.95f),
                            shadowElevation = 3.dp,
                            modifier = Modifier.width(170.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = note.text,
                                    fontSize = 11.sp,
                                    color = Color.Black,
                                    maxLines = 4,
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(
                                    onClick = { onDeleteNote(note.id) },
                                    modifier = Modifier.size(20.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Delete note",
                                        tint = Color.Black,
                                        modifier = Modifier.size(12.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Page Number Badge at bottom right
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(8.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color.Black.copy(alpha = 0.6f))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "${pageIndex + 1}",
                    color = Color.White,
                    fontSize = 11.sp
                )
            }
        }
    }
}
