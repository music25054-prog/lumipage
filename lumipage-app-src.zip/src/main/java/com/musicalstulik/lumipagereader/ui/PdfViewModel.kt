package com.musicalstulik.lumipagereader.ui

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.musicalstulik.lumipagereader.data.PdfRenderEngine
import com.musicalstulik.lumipagereader.data.RecentFilesManager
import com.musicalstulik.lumipagereader.data.RecentPdfItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class ViewMode {
    CONTINUOUS_SCROLL,
    SINGLE_PAGE
}

sealed interface PdfUiState {
    object Empty : PdfUiState
    object Loading : PdfUiState
    data class Success(
        val fileName: String,
        val pageCount: Int,
        val uri: Uri
    ) : PdfUiState
    data class Error(val message: String) : PdfUiState
}

class PdfViewModel : ViewModel() {

    private val _uiState = MutableStateFlow<PdfUiState>(PdfUiState.Empty)
    val uiState: StateFlow<PdfUiState> = _uiState.asStateFlow()

    private val _currentPage = MutableStateFlow(0)
    val currentPage: StateFlow<Int> = _currentPage.asStateFlow()

    private val _viewMode = MutableStateFlow(ViewMode.CONTINUOUS_SCROLL)
    val viewMode: StateFlow<ViewMode> = _viewMode.asStateFlow()

    private val _zoomScale = MutableStateFlow(1.0f)
    val zoomScale: StateFlow<Float> = _zoomScale.asStateFlow()

    private val _recentFiles = MutableStateFlow<List<RecentPdfItem>>(emptyList())
    val recentFiles: StateFlow<List<RecentPdfItem>> = _recentFiles.asStateFlow()

    private val _showGoToPageDialog = MutableStateFlow(false)
    val showGoToPageDialog: StateFlow<Boolean> = _showGoToPageDialog.asStateFlow()

    private var pdfEngine: PdfRenderEngine? = null
    private var recentFilesManager: RecentFilesManager? = null

    fun initRecentManager(context: Context) {
        if (recentFilesManager == null) {
            recentFilesManager = RecentFilesManager(context.applicationContext)
            loadRecentFiles()
        }
    }

    fun loadRecentFiles() {
        _recentFiles.value = recentFilesManager?.getRecentFiles() ?: emptyList()
    }

    fun openPdf(context: Context, uri: Uri) {
        viewModelScope.launch {
            _uiState.value = PdfUiState.Loading

            // Take persistable permission if available
            try {
                val takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION
                context.contentResolver.takePersistableUriPermission(uri, takeFlags)
            } catch (e: Exception) {
                // Ignore if not supported or not allowed
            }

            // Close existing engine
            pdfEngine?.close()
            pdfEngine = null

            try {
                val engine = PdfRenderEngine(context.applicationContext, uri)
                pdfEngine = engine

                initRecentManager(context)
                
                val savedLastPage = recentFilesManager?.getRecentFiles()
                    ?.firstOrNull { it.uriString == uri.toString() }?.lastPage ?: 0

                val initialPage = if (savedLastPage in 0 until engine.pageCount) savedLastPage else 0
                _currentPage.value = initialPage
                _zoomScale.value = 1.0f

                recentFilesManager?.addOrUpdateRecentFile(
                    uri = uri,
                    fileName = engine.fileName,
                    totalPages = engine.pageCount,
                    lastPage = initialPage
                )
                loadRecentFiles()

                _uiState.value = PdfUiState.Success(
                    fileName = engine.fileName,
                    pageCount = engine.pageCount,
                    uri = uri
                )
            } catch (e: IllegalArgumentException) {
                _uiState.value = PdfUiState.Error(e.message ?: "Failed to open PDF document.")
            } catch (e: Exception) {
                _uiState.value = PdfUiState.Error("An error occurred while opening the PDF: ${e.localizedMessage}")
            }
        }
    }

    suspend fun renderPage(pageIndex: Int, targetWidthPx: Int, scale: Float = 1.0f): Bitmap? {
        return pdfEngine?.renderPage(pageIndex, targetWidthPx, scale)
    }

    fun getPageAspectRatio(pageIndex: Int): Float {
        return pdfEngine?.getPageAspectRatio(pageIndex) ?: 1.414f
    }

    fun setCurrentPage(page: Int) {
        val state = _uiState.value
        if (state is PdfUiState.Success) {
            val clampedPage = page.coerceIn(0, state.pageCount - 1)
            _currentPage.value = clampedPage
            pdfEngine?.let { engine ->
                recentFilesManager?.updateLastPage(engine.uri, clampedPage)
            }
        }
    }

    fun setViewMode(mode: ViewMode) {
        _viewMode.value = mode
    }

    fun toggleViewMode() {
        _viewMode.update {
            if (it == ViewMode.CONTINUOUS_SCROLL) ViewMode.SINGLE_PAGE else ViewMode.CONTINUOUS_SCROLL
        }
    }

    fun setZoomScale(scale: Float) {
        _zoomScale.value = scale.coerceIn(0.5f, 3.5f)
    }

    fun zoomIn() {
        setZoomScale(_zoomScale.value + 0.25f)
    }

    fun zoomOut() {
        setZoomScale(_zoomScale.value - 0.25f)
    }

    fun resetZoom() {
        _zoomScale.value = 1.0f
    }

    fun setShowGoToPageDialog(show: Boolean) {
        _showGoToPageDialog.value = show
    }

    fun closeDocument() {
        pdfEngine?.close()
        pdfEngine = null
        _uiState.value = PdfUiState.Empty
        _currentPage.value = 0
        _zoomScale.value = 1.0f
    }

    fun removeRecentFile(uriString: String) {
        recentFilesManager?.removeRecentFile(uriString)
        loadRecentFiles()
    }

    fun clearRecentFiles() {
        recentFilesManager?.clearAll()
        loadRecentFiles()
    }

    override fun onCleared() {
        super.onCleared()
        pdfEngine?.close()
        pdfEngine = null
    }
}
