package com.musicalstulik.lumipagereader.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp

@Composable
fun ContinuousPdfViewer(
    pageCount: Int,
    currentPage: Int,
    zoomScale: Float,
    renderPage: suspend (pageIndex: Int, targetWidthPx: Int, scale: Float) -> Bitmap?,
    getPageAspectRatio: (pageIndex: Int) -> Float,
    onPageChanged: (page: Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = currentPage)
    val navBarInsets = WindowInsets.navigationBars.asPaddingValues()
    val bottomInset = navBarInsets.calculateBottomPadding()

    // Scroll to page if changed externally (e.g., via dialog or bottom bar)
    LaunchedEffect(currentPage) {
        if (currentPage in 0 until pageCount && listState.firstVisibleItemIndex != currentPage) {
            listState.scrollToItem(currentPage)
        }
    }

    // Report page change as user scrolls
    val activePage by remember {
        derivedStateOf { listState.firstVisibleItemIndex }
    }

    LaunchedEffect(activePage) {
        if (activePage in 0 until pageCount) {
            onPageChanged(activePage)
        }
    }

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val density = LocalDensity.current
        val widthPx = with(density) { maxWidth.roundToPx() }

        LazyColumn(
            state = listState,
            contentPadding = PaddingValues(top = 8.dp, bottom = 80.dp + bottomInset),
            modifier = Modifier.fillMaxSize()
        ) {
            items(
                count = pageCount,
                key = { pageIndex -> pageIndex }
            ) { pageIndex ->
                val aspectRatio = remember(pageIndex) { getPageAspectRatio(pageIndex) }

                PdfPageCard(
                    pageIndex = pageIndex,
                    targetWidthPx = widthPx,
                    aspectRatio = aspectRatio,
                    renderPage = renderPage,
                    scale = zoomScale
                )
            }
        }
    }
}
