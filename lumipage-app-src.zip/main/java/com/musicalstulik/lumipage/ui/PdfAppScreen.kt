package com.musicalstulik.lumipage.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.musicalstulik.lumipage.ui.components.ContinuousPdfViewer
import com.musicalstulik.lumipage.ui.components.EmptyPdfState
import com.musicalstulik.lumipage.ui.components.GoToPageDialog
import com.musicalstulik.lumipage.ui.components.SinglePdfViewer

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfAppScreen(
    viewModel: PdfViewModel,
    initialUri: Uri? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()
    val currentPage by viewModel.currentPage.collectAsState()
    val viewMode by viewModel.viewMode.collectAsState()
    val zoomScale by viewModel.zoomScale.collectAsState()
    val recentFiles by viewModel.recentFiles.collectAsState()
    val showGoToPageDialog by viewModel.showGoToPageDialog.collectAsState()

    // File picker launcher
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let { viewModel.openPdf(context, it) }
    }

    LaunchedEffect(Unit) {
        viewModel.initRecentManager(context)
        if (initialUri != null) {
            viewModel.openPdf(context, initialUri)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = when (val state = uiState) {
                                is PdfUiState.Success -> state.fileName
                                else -> "Lumipage PDF Reader"
                            },
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        if (uiState is PdfUiState.Success) {
                            val success = uiState as PdfUiState.Success
                            Text(
                                text = "Page ${currentPage + 1} of ${success.pageCount}",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                navigationIcon = {
                    if (uiState is PdfUiState.Success || uiState is PdfUiState.Error) {
                        IconButton(onClick = { viewModel.closeDocument() }) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Close PDF"
                            )
                        }
                    }
                },
                actions = {
                    if (uiState is PdfUiState.Success) {
                        val success = uiState as PdfUiState.Success

                        // Page indicator button -> triggers Jump to Page Dialog
                        Surface(
                            onClick = { viewModel.setShowGoToPageDialog(true) },
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.padding(end = 4.dp)
                        ) {
                            Text(
                                text = "${currentPage + 1}/${success.pageCount}",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }

                        // Toggle View Mode (Continuous vs Single Page)
                        IconButton(onClick = { viewModel.toggleViewMode() }) {
                            Text(
                                text = if (viewMode == ViewMode.CONTINUOUS_SCROLL) "1P" else "ALL",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        // Share PDF
                        IconButton(onClick = { sharePdf(context, success.uri) }) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = "Share PDF"
                            )
                        }
                    }

                    // Language Toggle Button (RU / EN)
                    val currentLocales = AppCompatDelegate.getApplicationLocales()
                    val currentLang = if (!currentLocales.isEmpty) currentLocales[0]?.language else java.util.Locale.getDefault().language
                    val isRussian = currentLang == "ru"
                    Surface(
                        onClick = {
                            val newLang = if (isRussian) "en" else "ru"
                            AppCompatDelegate.setApplicationLocales(
                                LocaleListCompat.forLanguageTags(newLang)
                            )
                        },
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        modifier = Modifier.padding(end = 4.dp)
                    ) {
                        Text(
                            text = if (isRussian) "RU" else "EN",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }

                    // Open File Button
                    IconButton(onClick = { filePickerLauncher.launch(arrayOf("application/pdf")) }) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Open PDF"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            if (uiState is PdfUiState.Success) {
                Surface(
                    shadowElevation = 8.dp,
                    color = MaterialTheme.colorScheme.surfaceContainer
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .navigationBarsPadding()
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // View Mode Indicator
                        Text(
                            text = if (viewMode == ViewMode.CONTINUOUS_SCROLL) "Scroll Mode" else "Page Mode",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        // Zoom Controls
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            TextButton(onClick = { viewModel.zoomOut() }) {
                                Text("-", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            }

                            TextButton(onClick = { viewModel.resetZoom() }) {
                                Text("${(zoomScale * 100).toInt()}%", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            }

                            TextButton(onClick = { viewModel.zoomIn() }) {
                                Text("+", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        },
        modifier = modifier
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (val state = uiState) {
                is PdfUiState.Empty -> {
                    EmptyPdfState(
                        recentFiles = recentFiles,
                        onOpenFilePicker = { filePickerLauncher.launch(arrayOf("application/pdf")) },
                        onSelectRecentFile = { uri -> viewModel.openPdf(context, uri) },
                        onRemoveRecentFile = { uriStr -> viewModel.removeRecentFile(uriStr) },
                        onClearAllRecent = { viewModel.clearRecentFiles() }
                    )
                }

                is PdfUiState.Loading -> {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(text = "Loading PDF document...", fontSize = 16.sp)
                    }
                }

                is PdfUiState.Error -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "Cannot Open Document",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = state.message,
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                Button(onClick = { filePickerLauncher.launch(arrayOf("application/pdf")) }) {
                                    Text("Open Another File")
                                }
                            }
                        }
                    }
                }

                is PdfUiState.Success -> {
                    if (viewMode == ViewMode.CONTINUOUS_SCROLL) {
                        ContinuousPdfViewer(
                            pageCount = state.pageCount,
                            currentPage = currentPage,
                            zoomScale = zoomScale,
                            renderPage = { index, widthPx, scale -> viewModel.renderPage(index, widthPx, scale) },
                            getPageAspectRatio = { index -> viewModel.getPageAspectRatio(index) },
                            onPageChanged = { page -> viewModel.setCurrentPage(page) }
                        )
                    } else {
                        SinglePdfViewer(
                            pageCount = state.pageCount,
                            currentPage = currentPage,
                            zoomScale = zoomScale,
                            renderPage = { index, widthPx, scale -> viewModel.renderPage(index, widthPx, scale) },
                            getPageAspectRatio = { index -> viewModel.getPageAspectRatio(index) },
                            onNextPage = { viewModel.setCurrentPage(currentPage + 1) },
                            onPreviousPage = { viewModel.setCurrentPage(currentPage - 1) }
                        )
                    }

                    if (showGoToPageDialog) {
                        GoToPageDialog(
                            currentPage = currentPage,
                            pageCount = state.pageCount,
                            onDismiss = { viewModel.setShowGoToPageDialog(false) },
                            onGoToPage = { targetPage -> viewModel.setCurrentPage(targetPage) }
                        )
                    }
                }
            }
        }
    }
}

private fun sharePdf(context: Context, uri: Uri) {
    try {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Share PDF Document"))
    } catch (e: Exception) {
        e.printStackTrace()
    }
}
