package com.musicalstulik.lumipage.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import android.util.LruCache
import java.io.Closeable
import java.io.File

class PdfRenderEngine(
    private val context: Context,
    val uri: Uri
) : Closeable {

    private var parcelFileDescriptor: ParcelFileDescriptor? = null
    private var pdfRenderer: PdfRenderer? = null

    val pageCount: Int
    val fileName: String

    private val mutex = Mutex()
    
    // Cache up to 25 rendered page bitmaps in memory
    private val bitmapCache = object : LruCache<String, Bitmap>(25) {
        override fun sizeOf(key: String, value: Bitmap): Int {
            return 1 // count by entries
        }
    }

    init {
        val pfd = context.contentResolver.openFileDescriptor(uri, "r")
            ?: throw IllegalArgumentException("Failed to open file descriptor for URI: $uri")
        
        parcelFileDescriptor = pfd
        
        try {
            val renderer = PdfRenderer(pfd)
            pdfRenderer = renderer
            pageCount = renderer.pageCount
        } catch (e: SecurityException) {
            pfd.close()
            throw IllegalArgumentException("PDF file is password-protected or encrypted.", e)
        } catch (e: Exception) {
            pfd.close()
            throw IllegalArgumentException("Invalid or corrupted PDF file.", e)
        }

        fileName = resolveFileName(context, uri)
    }

    suspend fun renderPage(
        pageIndex: Int,
        targetWidthPx: Int,
        scale: Float = 1.0f
    ): Bitmap? = withContext(Dispatchers.IO) {
        if (pageIndex !in 0 until pageCount) return@withContext null

        val scaledWidth = (targetWidthPx * scale).toInt().coerceAtLeast(100)
        val cacheKey = "$pageIndex-$scaledWidth"

        bitmapCache.get(cacheKey)?.let { cachedBitmap ->
            if (!cachedBitmap.isRecycled) {
                return@withContext cachedBitmap
            }
        }

        mutex.withLock {
            val renderer = pdfRenderer ?: return@withContext null
            if (pageIndex >= renderer.pageCount) return@withContext null

            var page: PdfRenderer.Page? = null
            try {
                page = renderer.openPage(pageIndex)
                val pdfWidth = page.width
                val pdfHeight = page.height

                val aspectRatio = pdfHeight.toFloat() / pdfWidth.toFloat()
                val targetHeight = (scaledWidth * aspectRatio).toInt().coerceAtLeast(100)

                val bitmap = Bitmap.createBitmap(
                    scaledWidth,
                    targetHeight,
                    Bitmap.Config.ARGB_8888
                )

                // Fill background with solid white (since PDF pages can have transparent background)
                val canvas = Canvas(bitmap)
                canvas.drawColor(Color.WHITE)

                page.render(
                    bitmap,
                    null,
                    null,
                    PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY
                )

                bitmapCache.put(cacheKey, bitmap)
                return@withContext bitmap
            } catch (e: Exception) {
                e.printStackTrace()
                return@withContext null
            } finally {
                page?.close()
            }
        }
    }

    fun getPageAspectRatio(pageIndex: Int): Float {
        if (pageIndex !in 0 until pageCount) return 1.414f // Standard A4 ratio fallback
        val renderer = pdfRenderer ?: return 1.414f
        return try {
            val page = renderer.openPage(pageIndex)
            val ratio = page.height.toFloat() / page.width.toFloat()
            page.close()
            ratio
        } catch (e: Exception) {
            1.414f
        }
    }

    override fun close() {
        bitmapCache.evictAll()
        try {
            pdfRenderer?.close()
        } catch (ignored: Exception) {}
        pdfRenderer = null

        try {
            parcelFileDescriptor?.close()
        } catch (ignored: Exception) {}
        parcelFileDescriptor = null
    }

    companion object {
        private fun resolveFileName(context: Context, uri: Uri): String {
            if (uri.scheme == "content") {
                try {
                    context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                        val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (nameIndex != -1 && cursor.moveToFirst()) {
                            val name = cursor.getString(nameIndex)
                            if (!name.isNull_or_blank()) return name
                        }
                    }
                } catch (e: Exception) {
                    // Fallback to last path segment
                }
            } else if (uri.scheme == "file") {
                val path = uri.path
                if (path != null) {
                    val file = File(path)
                    if (file.name.isNotBlank()) return file.name
                }
            }
            return uri.lastPathSegment ?: "Document.pdf"
        }

        private fun String?.isNull_or_blank(): Boolean {
            return this == null || this.trim().isEmpty()
        }
    }
}
