package com.musicalstulik.lumipage

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.musicalstulik.lumipage.ui.PdfAppScreen
import com.musicalstulik.lumipage.ui.PdfViewModel
import com.musicalstulik.lumipage.ui.theme.LumipageTheme

class MainActivity : AppCompatActivity() {

    private val viewModel: PdfViewModel by viewModels()
    private var initialPdfUri by mutableStateOf<Uri?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        extractPdfUri(intent)?.let { uri ->
            initialPdfUri = uri
        }

        setContent {
            LumipageTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    PdfAppScreen(
                        viewModel = viewModel,
                        initialUri = initialPdfUri
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        extractPdfUri(intent)?.let { uri ->
            initialPdfUri = uri
            viewModel.openPdf(this, uri)
        }
    }

    private fun extractPdfUri(intent: Intent?): Uri? {
        if (intent == null) return null
        val action = intent.action
        val data = intent.data
        if ((action == Intent.ACTION_VIEW || action == Intent.ACTION_OPEN_DOCUMENT) && data != null) {
            return data
        }
        return null
    }
}
